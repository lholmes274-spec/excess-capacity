// @ts-nocheck
"use client";

import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";

// ✅ Add props type declaration for session
interface SubscribeButtonProps {
  session: any; // You can replace 'any' with Supabase types later if desired
}

export default function SubscribeButton({ session }: SubscribeButtonProps) {
  const router = useRouter();

  const handleSubscribe = async () => {
    if (!session?.user) {
      alert("Please sign in to subscribe.");
      router.push("/login");
      return;
    }

    try {
      const response = await fetch("/api/stripe/create-subscription", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: session.user.id }),
      });

      const data = await response.json();

      if (data?.url) {
        window.location.href = data.url;
      } else {
        alert("Something went wrong. Please try again.");
      }
    } catch (err) {
      console.error(err);
      alert("Error starting subscription.");
    }
  };

  return (
    <button
      onClick={handleSubscribe}
      className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-md transition"
    >
      Subscribe for $9.99/month
    </button>
  );
}
